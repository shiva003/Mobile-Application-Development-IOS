//
//  API.swift
//  WeatherApplication
//
//  Created by Venkat Ramana Reddy on 10/20/22.
//

import Foundation

class NetworkService {
    static let shared = NetworkService()
    
    let URL_API_KEY = "4b92900b4210c518c5e040208deb8ae1"
    var URL_LATITUDE_KEY = "URL_LATITUDE"
    var URL_LONGITUDE_KEY = "URL_LONGITUDE"
    var URL_LATITUDE = UserDefaults.standard.string(forKey: "URL_LATITUDE")
    var URL_LONGITUDE = UserDefaults.standard.string(forKey: "URL_LONGITUDE")
    var DEGREE = UserDefaults.standard.string(forKey: "DEGREE") ?? "imperial"
    
    var URL_GET_ONE_CALL = ""
    let URL_BASE = "https://api.openweathermap.org/data/2.5"
    
    let session = URLSession(configuration: .default)
    
    func getURLFor(lat: String, lon: String) -> String {
        
        print("\(URL_BASE)/onecall?lat=\(lat)&lon=\(lon)&exclude=minutely&appid=\(URL_API_KEY)&units=\(DEGREE)")
        return "\(URL_BASE)/onecall?lat=\(lat)&lon=\(lon)&exclude=minutely&appid=\(URL_API_KEY)&units=\(DEGREE)"
    }
    
    func reloadCoordinates(){
        URL_LATITUDE = UserDefaults.standard.string(forKey: URL_LATITUDE_KEY)
        URL_LONGITUDE = UserDefaults.standard.string(forKey: URL_LONGITUDE_KEY)
    }
    
    func reloadDegree(){
        DEGREE = UserDefaults.standard.string(forKey: "DEGREE") ?? "imperial"
    }
    
    func setLatitude(_ latitude: String) {
        URL_LATITUDE = latitude
    }
    
    func setLatitude(_ latitude: Double) {
        setLatitude(String(latitude))
    }
    
    func setLongitude(_ longitude: String) {
        URL_LONGITUDE = longitude
    }
    
    func setLongitude(_ longitude: Double) {
        setLongitude(String(longitude))
    }
    
    func getWeather(onSuccess: @escaping (Result) -> Void, onError: @escaping (String) -> Void) {
        guard let url = URL(string: getURLFor(lat: URL_LATITUDE ?? "29.7604", lon: URL_LONGITUDE ?? "-95.3698")) else {
            onError("Error building URL")
            return
        }
        
        let task = session.dataTask(with: url) { (data, response, error) in
            
            DispatchQueue.main.async {
                if let error = error {
                    onError(error.localizedDescription)
                    return
                }
                
                guard let data = data, let response = response as? HTTPURLResponse else {
                    onError("Invalid data or response")
                    return
                }
                
                do {
                    if response.statusCode == 200 {
                        let items = try JSONDecoder().decode(Result.self, from: data)
                        onSuccess(items)
                    } else {
                        onError("Response wasn't 200. It was: " + "\n\(response.statusCode)")
                    }
                } catch {
                    onError(error.localizedDescription)
                }
            }
            
        }
        task.resume()
    }
    
}
