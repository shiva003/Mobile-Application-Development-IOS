//
//  HomeVC.swift
//  WeatherApplication
//
//  Created by Shiva Medapati on 10/20/22.
//

import UIKit

class HomeVC: UIViewController {
    @IBOutlet weak var dateLbl: UILabel!
    @IBOutlet weak var cityLbl: UILabel!
    @IBOutlet weak var tempLbl: UILabel!
    var tempimg:Double = 0.00
    
    @IBOutlet weak var HourlyCollectionView: UICollectionView!
    
    @IBOutlet weak var DailyTableView: UITableView!
    @IBOutlet weak var imageView: UIImageView!
    var weatherResult: Result?
    var hourly = [Hourly]()
    var daily  = [Daily]()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        getWeather()
        HourlyCollectionView.delegate = self
        HourlyCollectionView.dataSource = self
        DailyTableView.delegate = self
        DailyTableView.dataSource = self
        imageView.image = UIImage()
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        getWeather()
        HourlyCollectionView.delegate = self
        HourlyCollectionView.dataSource = self
        DailyTableView.delegate = self
        DailyTableView.dataSource = self
        imageView.image = UIImage()
    }

    func getWeather() {
        NetworkService.shared.getWeather(onSuccess: { [self] (result) in
            self.weatherResult = result
            
            self.weatherResult?.sortDailyArray()
            self.weatherResult?.sortHourlyArray()
            let date = Date()
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd/MM/yyyy "
            var degree = " F"
            var degreeUD =  UserDefaults.standard.string(forKey: "DEGREE") ?? "imperial"
            if degreeUD == "metric"{
                degree = " C"
            }
            
            tempLbl.text = String((self.weatherResult?.current.temp)!) + degree
            cityLbl.text = UserDefaults.standard.string(forKey: "CITY") ?? "Houston"
            dateLbl.text = dateFormatter.string(from: date)
            if let temp = self.weatherResult?.current.temp{
                print(temp)
                tempimg = temp
            }
            if degree == " F"
            {
                if  tempimg < 70{
                    imageView.image = UIImage(named: "cold.png")
                }
                if (tempimg >= 70) && (tempimg <= 80) {
                    imageView.image = UIImage(named: "pleasant.png")
                }
                if (tempimg > 80)
                {
                    imageView.image = UIImage(named: "hot.png")
                }
            }
            else if degree == " C"
            {
                if  tempimg < 21{
                    imageView.image = UIImage(named: "cold.png")
                }
                if (tempimg >= 21) && (tempimg <= 27) {
                    imageView.image = UIImage(named: "pleasant.png")
                }
                if (tempimg > 27)
                {
                    imageView.image = UIImage(named: "hot.png")
                }
            }
            
            //self.updateViews()
            if let hourlydata = self.weatherResult?.hourly{
                hourly = hourlydata
            }
            HourlyCollectionView.reloadData()
            if let dailydata = self.weatherResult?.daily{
                daily = dailydata
            }
            DailyTableView.reloadData()
            // print(self.weatherResult?.hourly)
        }) { (errorMessage) in
            debugPrint(errorMessage)
        }
    }
    
}

extension HomeVC: UICollectionViewDelegate,UICollectionViewDataSource{
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return hourly.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let Cell = collectionView.dequeueReusableCell(withReuseIdentifier: "HourlyCell", for: indexPath) as! HourlyCollectionViewCell
        var degree = " F"
        var degreeUD =  UserDefaults.standard.string(forKey: "DEGREE") ?? "imperial"
        if degreeUD == "metric"{
            degree = " C"
        }
        if degree == " F"
        {
            if  hourly[indexPath.row].temp < 70{
                Cell.houlyimglbl.image = UIImage(named: "cold.png")
            }
            if (hourly[indexPath.row].temp >= 70) && (hourly[indexPath.row].temp <= 80) {
                Cell.houlyimglbl.image = UIImage(named: "pleasant.png")
            }
            if (hourly[indexPath.row].temp > 80)
            {
                Cell.houlyimglbl.image = UIImage(named: "hot.png")
            }
        }
        else if degree == " C"
        {
            if  hourly[indexPath.row].temp < 21{
                Cell.houlyimglbl.image = UIImage(named: "cold.png")
            }
            if (hourly[indexPath.row].temp >= 21) && (hourly[indexPath.row].temp <= 27) {
                Cell.houlyimglbl.image = UIImage(named: "pleasant.png")
            }
            if (hourly[indexPath.row].temp > 27)
            {
                Cell.houlyimglbl.image = UIImage(named: "hot.png")
            }
        }
        let timeInterval = TimeInterval(hourly[indexPath.row].dt)
        let myNSDate = Date(timeIntervalSince1970: timeInterval)
        let formatter = DateFormatter()
        formatter.dateFormat = "MM/d HH:mm"
        Cell.templbl.text = String(hourly[indexPath.row].temp) + degree
        Cell.Timelbl.text = formatter.string(from: myNSDate)
        //Cell.hourlyimglbl.image =
        return Cell
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    
}
extension HomeVC: UITableViewDelegate,UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return daily.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var degree = " F"
        var degreeUD =  UserDefaults.standard.string(forKey: "DEGREE") ?? "imperial"
        if degreeUD == "metric"{
            degree = " C"
        }
        
        let timeInterval = TimeInterval(daily[indexPath.row].dt)
        let myNSDate = Date(timeIntervalSince1970: timeInterval)
        let formatter = DateFormatter()
        formatter.dateFormat = "MM/d/YYYY"
        
        let Cell = tableView.dequeueReusableCell(withIdentifier: "DailyCell", for: indexPath) as! DailyTableViewCell
        Cell.DayLbl.text =  formatter.string(from: myNSDate)
        Cell.TempLbl.text = String(daily[indexPath.row].temp.day) + degree
        //Cell.Dailyimglbl.image =
        if degree == " F"
        {
            if  hourly[indexPath.row].temp < 70{
                Cell.Dailyimglbl.image = UIImage(named: "cold.png")
            }
            if (hourly[indexPath.row].temp >= 70) && (hourly[indexPath.row].temp <= 80) {
                Cell.Dailyimglbl.image = UIImage(named: "pleasant.png")
            }
            if (hourly[indexPath.row].temp > 80)
            {
                Cell.Dailyimglbl.image = UIImage(named: "hot.png")
            }
        }
        else if degree == " C"
        {
            if  hourly[indexPath.row].temp < 21{
                Cell.Dailyimglbl.image = UIImage(named: "cold.png")
            }
            if (hourly[indexPath.row].temp >= 21) && (hourly[indexPath.row].temp <= 27) {
                Cell.Dailyimglbl.image = UIImage(named: "pleasant.png")
            }
            if (hourly[indexPath.row].temp > 27)
            {
                Cell.Dailyimglbl.image = UIImage(named: "hot.png")
            }
        }
        
        return Cell
    }
    
    
}
