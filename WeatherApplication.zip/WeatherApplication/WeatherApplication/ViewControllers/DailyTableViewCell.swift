//
//  DailyTableViewCell.swift
//  WeatherApplication
//
//  Created by Shiva Medapati on 11/20/22.
//

import UIKit

class DailyTableViewCell: UITableViewCell {
    
    @IBOutlet weak var Dailyimglbl: UIImageView!
    @IBOutlet weak var DayLbl: UILabel!
    @IBOutlet weak var TempLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
