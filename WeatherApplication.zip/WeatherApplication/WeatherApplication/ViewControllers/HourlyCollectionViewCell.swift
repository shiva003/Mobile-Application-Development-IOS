//
//  HourlyCollectionViewCell.swift
//  WeatherApplication
//
//  Created by Shiva Medapati on 11/20/22.
//

import UIKit

class HourlyCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var houlyimglbl: UIImageView!
    @IBOutlet weak var templbl: UILabel!
    @IBOutlet weak var Timelbl: UILabel!
}
