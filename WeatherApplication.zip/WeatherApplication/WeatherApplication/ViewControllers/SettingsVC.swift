//
//  SettingsVC.swift
//  WeatherApplication
//
//  Created by Shiva Medapati on 10/20/22.
//

import UIKit

class SettingsVC: UIViewController {
    var URL_LATITUDE_KEY = "URL_LATITUDE"
    var URL_LONGITUDE_KEY = "URL_LONGITUDE"
    var CITY_KEY = "CITY"
    var DEGREE_KEY = "DEGREE"
    
    @IBOutlet weak var CityDisplayLbl: UILabel!
    @IBOutlet weak var segmentSelection: UISegmentedControl!
    
    @IBAction func segmentChange(_ sender: Any) {
        switch segmentSelection.selectedSegmentIndex{
        case 0:
            UserDefaults.standard.set("imperial", forKey: DEGREE_KEY)
        case 1:
            UserDefaults.standard.set("metric", forKey: DEGREE_KEY)
        default:
            UserDefaults.standard.set("imperial", forKey: DEGREE_KEY)
        }
        NetworkService.shared.reloadDegree()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if UserDefaults.standard.string(forKey: DEGREE_KEY) == "metric"{
            segmentSelection.selectedSegmentIndex = 1
        }
        updateFavCity()
        // Do any additional setup after loading the view.
    }
    func updateFavCity(){
        let city = UserDefaults.standard.string(forKey: CITY_KEY) ?? "Houston"
        CityDisplayLbl.text = "Favourite City : " + city
    }
    @IBAction func Austinbtnactn(_ sender: Any) {
        UserDefaults.standard.set("30.2672", forKey: URL_LATITUDE_KEY)
        UserDefaults.standard.set("-97.7431", forKey: URL_LONGITUDE_KEY)
        UserDefaults.standard.set("Austin", forKey: CITY_KEY)
        NetworkService.shared.reloadCoordinates()
        updateFavCity()
    }
    @IBAction func Dallasbtnactn(_ sender: Any) {
        UserDefaults.standard.set("32.7767", forKey: URL_LATITUDE_KEY)
        UserDefaults.standard.set("-96.7970", forKey: URL_LONGITUDE_KEY)
        UserDefaults.standard.set("Dallas", forKey: CITY_KEY)
        NetworkService.shared.reloadCoordinates()
        updateFavCity()
    }
    @IBAction func Houstonbtnactn(_ sender: Any) {
        UserDefaults.standard.set("29.7604", forKey: URL_LATITUDE_KEY)
        UserDefaults.standard.set("-95.3698", forKey: URL_LONGITUDE_KEY)
        UserDefaults.standard.set("Houston", forKey: CITY_KEY)
        NetworkService.shared.reloadCoordinates()
        updateFavCity()
    }
    @IBAction func SanAntoniobtnactn(_ sender: Any) {
        UserDefaults.standard.set("29.4252", forKey: URL_LATITUDE_KEY)
        UserDefaults.standard.set("-98.4946", forKey: URL_LONGITUDE_KEY)
        UserDefaults.standard.set("San Antonio", forKey: CITY_KEY)
        NetworkService.shared.reloadCoordinates()
        updateFavCity()
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
